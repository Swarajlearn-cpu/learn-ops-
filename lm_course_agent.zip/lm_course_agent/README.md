# LM Course Tutor (Streamlit + Groq Llama)

Chat tutor that reads your Logistics Management course files (`course_files/`) and answers like a Professor of
Supply Chain, Operations Research and Cost Accounting, citing the file, sheet and page it used.

## Run locally
    pip install -r requirements.txt
    mkdir -p .streamlit && cp .streamlit/secrets.toml.example .streamlit/secrets.toml   # paste your Groq key
    streamlit run app.py

## Deploy free on Streamlit Community Cloud
1. Push this whole folder (including `course_files/`) to a GitHub repo. Do NOT push `.streamlit/secrets.toml`.
2. share.streamlit.io > New app > pick the repo > main file `app.py`.
3. Advanced settings > Secrets > `GROQ_API_KEY = "gsk_..."` > Deploy.

## Notes
- No API key? The Library and Solver X-Ray tabs and the "library-only" chat still work.
- Add new material by dropping files into `course_files/` (PDF, DOCX, XLSX, TXT) or with the sidebar uploader.
- Groq model names and free limits change; use the Custom model ID box if a preset is unavailable.
